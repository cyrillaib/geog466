// Simplified version placeholder
const map = L.map("map").setView([49.3, 4.3], 8);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);
